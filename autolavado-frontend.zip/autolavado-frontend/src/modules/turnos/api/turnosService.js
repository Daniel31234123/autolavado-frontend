import { http } from "../../../api/httpClient.js";

/**
 * @typedef {Object} Turno
 * @property {string} id
 * @property {string} numeroTurno
 * @property {string} placa
 * @property {number} tipoVehiculo    - ver constants/turnoEnums.js -> TIPO_VEHICULO
 * @property {string} telefonoCliente
 * @property {string} [idServicio]
 * @property {string} [idOperario]
 * @property {string} [idBahia]
 * @property {number} estadoActual    - ver constants/turnoEnums.js -> ESTADO_TURNO
 * @property {string} fechaIngreso
 * @property {string} hashConsulta
 */

/**
 * @typedef {Object} CrearTurnoRequest
 * @property {string} placa            - exactamente 6 caracteres
 * @property {number|null} tipoVehiculo
 * @property {string} telefonoCliente  - exactamente 10 dígitos
 * @property {string} [idServicio]
 * @property {string} [idOperario]
 * @property {string} [idBahia]
 */

/**
 * @typedef {Object} TurnoCreadoResponse
 * @property {string} idTurno
 * @property {string} numeroTurno
 * @property {number} estado
 * @property {string} hashConsulta
 * @property {string} qrUrl
 * @property {string} fechaIngreso
 */

export const turnosService = {
  /**
   * GET /api/v1/turnos/activos
   * @returns {Promise<Turno[]>}
   */
  getActivos: () => http.get("/api/v1/turnos/activos"),

  /**
   * POST /api/v1/turnos
   * @param {CrearTurnoRequest} payload
   * @returns {Promise<TurnoCreadoResponse>}
   */
  create: (payload) => http.post("/api/v1/turnos", payload),
};
