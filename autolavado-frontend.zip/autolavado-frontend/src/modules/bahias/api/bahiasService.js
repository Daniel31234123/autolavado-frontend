import { http } from "../../../api/httpClient.js";

/**
 * @typedef {Object} Bahia
 * @property {string} id
 * @property {string} nombreBahia
 * @property {number} tipo    - ver constants/bahiaEnums.js -> TIPO_BAHIA
 * @property {number} estado  - ver constants/bahiaEnums.js -> ESTADO_BAHIA
 */

export const bahiasService = {
  /**
   * GET /api/v1/bahias/disponibles
   * @returns {Promise<Bahia[]>}
   */
  getDisponibles: () => http.get("/api/v1/bahias/disponibles"),
};
